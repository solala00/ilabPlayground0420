//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let helloClosure={
    print("hello")
}

helloClosure()

func eat(foodName: String){
    print("i want to have \(foodName)")
}

var eatOperation = {(foodName: String) in print("i want to have \(foodName)")}
eat(foodName: "cake")

eatOperation("buffet")

func add(number1:Int, number2:Int)->Int{
    let result = number1 + number2
    return result
}

let a = add(number1:1,number2:2)
print(a)

var addOperation = {
    (number1:Int, number2:Int)->Int in
    let result = number1 + number2
    return result
}
print(addOperation(3,4))

var operation : (Double)->Double
operation = {(number) in return -number}
print(operation(5.0))

let primes = [2.0,3.0,5.0,7.0,11.0]
let negativePrimes = primes.map({-$0})
let invertPrimes = primes.map(){1.0/$0}
let stringPrimes = primes.map{String($0)}
print(negativePrimes)
print(invertPrimes)
print(stringPrimes)

func calc(num1:Int, num2:Int, operation:(Int, Int)-> Int){
    print(operation(num1,num2))
}

calc(num1: 4, num2: 7, operation: addOperation)

let numbers = [10, 8, 20, 7 ,56, 3, 2, 1, 99]
var finished = numbers.sorted(by:{$0>$1})
var singleNum = numbers.map({($0%10, $0)})
var lll = singleNum.sorted(by:{$0.0>$1.0})
print("answer:",lll.map({$0.1}))

print("before sorting")
for i in numbers{
    print("\(i)", terminator:" ")
}

print("\nafter sorting")
for i in finished{
    print("\(i)", terminator:" ")
}
print("")


